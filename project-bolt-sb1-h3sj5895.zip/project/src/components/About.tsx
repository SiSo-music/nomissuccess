import React from 'react';
import { Users, Target, Heart, Shield, Code, Zap } from 'lucide-react';

const About = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-slate-900 to-slate-800 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-blue-500/10"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* About nomissuccess */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Über <span className="bg-gradient-to-r from-emerald-400 to-blue-400 bg-clip-text text-transparent">nomissuccess</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-lg flex items-center justify-center shadow-lg">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Unser Team</h3>
                <p className="text-gray-300">
                  <strong>Simon Socha</strong> - Aufstrebender Jungunternehmer und Projektleiter
                </p>
                <p className="text-gray-300 mt-2">
                  <strong>Anthony Benz</strong> - Talentierter Programmierer und Web-Developer mit Expertise in MySQL, Docker und Kubernetes
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center shadow-lg">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Unsere Zielgruppe</h3>
                <p className="text-gray-300">
                  Regionale SMB wie Handwerker, Anwaltskanzleien, Restaurants, Metzger, Personalvermittler und mehr
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-xl p-8 border border-slate-700/50">
            <div className="flex items-center space-x-3 mb-6">
              <Heart className="w-8 h-8 text-emerald-400" />
              <h3 className="text-2xl font-bold text-white">Unser Motto</h3>
            </div>
            <blockquote className="text-gray-300 italic text-lg leading-relaxed mb-6">
              "Wahrer Mehrwert entsteht dort, wo technische Stabilität und kreatives Design in Einklang stehen. 
              So schaffen wir digitale Räume, in denen Vertrauen und Nutzungsfreude wachsen!"
            </blockquote>
          </div>
        </div>

        {/* Unsere Werte */}
        <div className="border-t border-slate-700/50 pt-20">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Unsere <span className="bg-gradient-to-r from-purple-400 to-emerald-400 bg-clip-text text-transparent">Werte</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Philosophy Quote */}
            <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm rounded-2xl shadow-xl p-8 border border-slate-700/50">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white">Unsere Philosophie</h3>
              </div>
              <blockquote className="text-gray-300 italic text-lg leading-relaxed">
                "Verantwortung entsteht dort, wo wir handeln. Indem wir technische Exzellenz mit ethischer Verantwortung verbinden, 
                schaffen wir Vertrauen – das wertvollste Gut im digitalen Zeitalter."
              </blockquote>
            </div>

            {/* Leitsatz */}
            <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm rounded-2xl shadow-xl p-8 border border-slate-700/50">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-lg flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white">Unser Leitsatz</h3>
              </div>
              <blockquote className="text-gray-300 italic text-lg leading-relaxed">
                "Risiko ist immer die Kehrseite von Freiheit. Indem wir bewusst entscheiden, welche Risiken wir absichern, 
                gestalten wir die Spielregeln unseres Handelns und definieren zugleich unsere Verantwortung im digitalen Raum."
              </blockquote>
            </div>
          </div>

          {/* Feature Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-blue-500/10 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6 text-center transition-all duration-300 hover:bg-blue-500/20 hover:border-blue-400/50 hover:shadow-lg hover:shadow-blue-500/25 hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-bold text-blue-400 mb-2">Sicherheit</h4>
              <p className="text-gray-300 text-sm">SSL & DSGVO-konform</p>
            </div>

            <div className="bg-emerald-500/10 backdrop-blur-sm border border-emerald-500/30 rounded-xl p-6 text-center transition-all duration-300 hover:bg-emerald-500/20 hover:border-emerald-400/50 hover:shadow-lg hover:shadow-emerald-500/25 hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-bold text-emerald-400 mb-2">Performance</h4>
              <p className="text-gray-300 text-sm">Schnell & optimiert</p>
            </div>

            <div className="bg-purple-500/10 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6 text-center transition-all duration-300 hover:bg-purple-500/20 hover:border-purple-400/50 hover:shadow-lg hover:shadow-purple-500/25 hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-bold text-purple-400 mb-2">Support</h4>
              <p className="text-gray-300 text-sm">Persönlich & schnell</p>
            </div>

            <div className="bg-orange-500/10 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6 text-center transition-all duration-300 hover:bg-orange-500/20 hover:border-orange-400/50 hover:shadow-lg hover:shadow-orange-500/25 hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-bold text-orange-400 mb-2">Zielgruppe</h4>
              <p className="text-gray-300 text-sm">Mittelstand-fokussiert</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;