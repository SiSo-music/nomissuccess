import React, { useEffect, useState } from 'react';

const Opening = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    setIsVisible(true);
    
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Calculate logo transform based on scroll
  const logoScale = Math.max(0.3, 1 - scrollY / 800);
  const logoOpacity = Math.max(0.1, 1 - scrollY / 600);

  return (
    <>
      {/* Fixed background logo that appears throughout the site */}
      <div 
        className="fixed inset-0 flex items-center justify-center pointer-events-none z-0"
        style={{
          opacity: scrollY > 400 ? Math.min(0.05, scrollY / 10000) : 0,
          transition: 'opacity 0.3s ease'
        }}
      >
        <img 
          src="/Logo9.png" 
          alt="nomissuccess Background Logo" 
          className="h-96 w-auto filter grayscale"
          style={{
            filter: `grayscale(1) brightness(${Math.min(2, scrollY / 1000)})`
          }}
        />
      </div>

      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-emerald-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse animation-delay-4000"></div>
        </div>

        {/* Main Logo with scroll-based scaling */}
        <div 
          className={`relative z-10 transition-all duration-2000 ${
            isVisible ? 'opacity-100' : 'opacity-0'
          }`}
          style={{
            transform: `scale(${logoScale})`,
            opacity: logoOpacity
          }}
        >
          <div className="text-center">
            <img 
              src="/Logo9.png" 
              alt="nomissuccess Logo" 
              className="h-64 w-auto mx-auto filter drop-shadow-2xl mb-8 transition-transform duration-1000 hover:scale-110"
            />
            <h1 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-emerald-400 via-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
              nomissuccess
            </h1>
            <p className="text-2xl text-gray-300 font-light">
              WILD DIGITAL SUCCESS
            </p>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-emerald-400/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-emerald-400/70 rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Opening;